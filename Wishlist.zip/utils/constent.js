import { ApiService } from "./ApiService";
export const apiService = new ApiService();
if (typeof window.wishlistClubMeta === "undefined") {
  window.wishlistClubMeta = { wcSetting: {}, wcCustomerId: "", wcShop: "" };
}
// export function showMessage(message, type = "success", duration = 5000, custom = {}) {
//   let messageDiv = document.getElementById("th-wl-success-msg");
//   if (!messageDiv) {
//     messageDiv = document.createElement("div");
//     messageDiv.id = "th-wl-success-msg";
//     messageDiv.style.position = "fixed";
//     messageDiv.style.top = "10px";
//     messageDiv.style.right = "10px";
//     messageDiv.style.color = "#fffff";
//     messageDiv.style.height = "50px";
//     messageDiv.style.display = "flex";
//     messageDiv.style.alignItems = "center";
//     messageDiv.style.justifyContent = "center";
//     messageDiv.style.padding = "10px 20px";
//     messageDiv.style.borderRadius = "5px";
//     messageDiv.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
//     messageDiv.style.zIndex = "999";
//     document.body.appendChild(messageDiv);
//   }

//   // Apply styles based on message type
//   switch (type) {
//     case "error":
//       messageDiv.style.background = "#f44336"; // Red
//       messageDiv.style.color = "#ffffff"; // Red
//       break;
//     case "custom":
//       if (custom && custom.background_color && custom.text_color) {
//         messageDiv.style.background = custom.background_color;
//         messageDiv.style.color = custom.text_color;
//       }
//       break;
//     case "info":
//       messageDiv.style.background = "#2196F3"; // Blue
//       messageDiv.style.color = "#ffffff"; // Red
//       break;
//     default:
//       messageDiv.style.background = "#04AA6D"; // Green (Success)
//       messageDiv.style.color = "#ffffff"; // Red
//   }

//   messageDiv.textContent = message;
//   messageDiv.style.display = "block";

//   setTimeout(() => {
//     messageDiv.style.display = "none";
//   }, duration);
// }
export const showMessage = (message, type = "success", duration = 5000, custom = {}) => {
  if (type == "success") {
    if (typeof $th_wishlistAdd_callback_successMessage == 'function') {
      $th_wishlistAdd_callback_successMessage(message);
    } else {
      document.querySelector('body').insertAdjacentHTML('beforeend', '<div id="th-wl-sucess-mgs" background = custom.background_color; >' + message + '</div></div>');
      setTimeout(function () { document.getElementById("th-wl-sucess-mgs").remove(); }, duration);
    }
  } else {
    if (typeof $th_wishlistAdd_callback_errorMessage == 'function') {
      $th_wishlistAdd_callback_errorMessage(message);
    } else {
      document.querySelector('body').insertAdjacentHTML('beforeend', '<div id="th-wl-error-mgs">' + message + '</div></div>');
      setTimeout(function () { document.getElementById("th-wl-error-mgs").remove(); }, duration);
    }
  }
}
export const { wcSetting, wcCustomerId, wcShop } = window.wishlistClubMeta;
export const wishlistData = function () {
  return JSON.parse(localStorage.getItem('wishlistClubData')) || null;
};
export const wishlistProducts = function () {
  return JSON.parse(localStorage.getItem('wishlistClubProducts')) || [];
};
export const wishlistVariant = function () {
  return JSON.parse(localStorage.getItem('wishlistClubVariant')) || [];
};

export const wcUniqueId = function (id) {
  const dateUniq = Date.now().toString(36) + Math.random().toString(36).substr(2);
  return `${dateUniq}`;
};

export const cartAddJson = async function (items) {
  const data = await apiService.addCartAPI({ items: items });
  return data
}

export const updateWishlistCount = function (count) {
  const wishlistclubElements = document.querySelectorAll(".th_wlc_product_count");
  wishlistclubElements.forEach((element) => {
    element.style.display = count >= 1 ? "flex" : "none";
    element.textContent = count;
  });
  localStorage.setItem("wishlistClubTotal", count);
};